## Packages
recharts | Dashboard charts for sales and inventory visualization
framer-motion | Smooth animations for page transitions and interactions
date-fns | Formatting dates for sales records

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
